Welcome to The Coin Collector!
This game is a simple arcade game to test
your movement skills. Move around and collect the coins.
Avoid all bombs in your adventure. Simple as that.

CONTROLS:
Start: start the game (on the title screen) OR go back to title screen (on end screen)
Select: Reset the game to the title from anywhere
Left Arrow Key: Move left
Right Arrow Key: Move right
Up Arrow Key: Move up
Down Arrow Key: Move down


