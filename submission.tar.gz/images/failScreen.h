/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=162x80 images/failScreen images/FailScreen.png 
 * Time-stamp: Wednesday 04/10/2019, 22:04:59
 * 
 * Image Information
 * -----------------
 * images/FailScreen.png 162@80
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FAILSCREEN_H
#define FAILSCREEN_H

extern const unsigned short FailScreen[12960];
#define FAILSCREEN_SIZE 25920
#define FAILSCREEN_LENGTH 12960
#define FAILSCREEN_WIDTH 162
#define FAILSCREEN_HEIGHT 80

#endif

