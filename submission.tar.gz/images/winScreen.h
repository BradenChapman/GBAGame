/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=161x80 images/winScreen images/WinScreen.png 
 * Time-stamp: Wednesday 04/10/2019, 21:49:01
 * 
 * Image Information
 * -----------------
 * images/WinScreen.png 161@80
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WINSCREEN_H
#define WINSCREEN_H

extern const unsigned short WinScreen[12880];
#define WINSCREEN_SIZE 25760
#define WINSCREEN_LENGTH 12880
#define WINSCREEN_WIDTH 161
#define WINSCREEN_HEIGHT 80

#endif

