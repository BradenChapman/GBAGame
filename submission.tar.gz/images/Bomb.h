/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=15x15 images/bomb images/Bomb.jpg 
 * Time-stamp: Tuesday 04/09/2019, 02:13:20
 * 
 * Image Information
 * -----------------
 * images/Bomb.jpg 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BOMB_H
#define BOMB_H

extern const unsigned short Bomb[225];
#define BOMB_SIZE 450
#define BOMB_LENGTH 225
#define BOMB_WIDTH 15
#define BOMB_HEIGHT 15

#endif

