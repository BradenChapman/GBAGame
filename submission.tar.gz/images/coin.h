/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=15x15 images/Coin images/Coin.jpg 
 * Time-stamp: Tuesday 04/09/2019, 01:38:52
 * 
 * Image Information
 * -----------------
 * images/Coin.jpg 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef COIN_H
#define COIN_H

extern const unsigned short Coin[225];
#define COIN_SIZE 450
#define COIN_LENGTH 225
#define COIN_WIDTH 15
#define COIN_HEIGHT 15

#endif

