/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 images/GameScreen images/GameScreen.png 
 * Time-stamp: Wednesday 04/10/2019, 22:18:51
 * 
 * Image Information
 * -----------------
 * images/GameScreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GAMESCREEN_H
#define GAMESCREEN_H

extern const unsigned short GameScreen[38400];
#define GAMESCREEN_SIZE 76800
#define GAMESCREEN_LENGTH 38400
#define GAMESCREEN_WIDTH 240
#define GAMESCREEN_HEIGHT 160

#endif

